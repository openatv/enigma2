#!/bin/sh

[ -x /usr/bin/ntpdate ] && /usr/bin/ntpdate -s -u ntp_server

exit 0 

